<h1 align="center">  Proyecto Integrador HTML, CSS y JavaScript </h1>

Este proyecto es una aplicación web de gestión de pedidos donde los usuarios pueden agregar, buscar, filtrar y eliminar productos.

<h3>
Pasos para la instalación y ejecución:
</h3>

1. Clonar el repositorio utilizando el comando: git clone https://github.com/LuciaSantibanez/IntegradorJS.git
2. Instalar las dependencias necesarias: npm install
3. Para ejecutar el proyecto en un entorno de desarrollo local utilizar el comando: npm run dev
